import { useState, useEffect } from "react";
import { VideoSection } from "@/components/video-feed";
import { ChatSection } from "@/components/chat-section";
import { PermissionModal } from "@/components/permission-modal";
import { LoadingModal } from "@/components/loading-modal";
import { MobileLayout } from "@/components/layouts/mobile-layout";
import { TabletLayout } from "@/components/layouts/tablet-layout";
import { DesktopLayout } from "@/components/layouts/desktop-layout";
import { SwarmIntelligencePanel } from "@/components/swarm-intelligence-panel";
import { useWebRTC } from "@/hooks/use-webrtc";
import { useWebSocket } from "@/hooks/use-websocket";
import { useDeviceManager } from "@/hooks/use-device-manager";
import { Video } from "lucide-react";

export default function VideoChat() {
  const [showPermissionModal, setShowPermissionModal] = useState(true);
  const [showLoadingModal, setShowLoadingModal] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [messages, setMessages] = useState<Array<{
    id: string;
    text: string;
    sender: 'self' | 'partner';
    timestamp: Date;
  }>>([]);

  // Device Manager Hook
  const { 
    deviceInfo, 
    layoutConfig, 
    isLoading: deviceLoading,
    isPhone, 
    isTablet, 
    isDesktop,
    isMobile 
  } = useDeviceManager();

  const {
    localStream,
    remoteStream,
    isVideoEnabled,
    isAudioEnabled,
    toggleVideo,
    toggleAudio,
    initializeMedia,
    createOffer,
    createAnswer,
    addIceCandidate,
    setRemoteDescription,
    cleanup
  } = useWebRTC();

  // WebSocket Hook
  const { isConnected: wsConnected, sendMessage } = useWebSocket({
    onMessage: (data) => {
      switch (data.type) {
        case 'offer':
          createAnswer(data.offer);
          break;
        case 'answer':
          setRemoteDescription(data.answer);
          break;
        case 'ice-candidate':
          addIceCandidate(data.candidate);
          break;
        case 'partner-found':
          if (!isConnected) {
            setIsConnected(true);
          }
          break;
        case 'partner-left':
          if (isConnected) {
            setIsConnected(false);
          }
          break;
        case 'chat-message':
          setMessages(prev => {
            const exists = prev.some(m => m.text === data.message && m.sender === 'partner');
            if (!exists) {
              return [...prev, {
                id: `partner-${Date.now()}-${Math.random()}`,
                text: data.message,
                sender: 'partner',
                timestamp: new Date()
              }];
            }
            return prev;
          });
          break;
      }
    }
  });

  const handlePermissionGranted = async () => {
    try {
      await initializeMedia();
      setShowPermissionModal(false);
      // Add system message
      setMessages([{
        id: 'system-1',
        text: 'Connected to chat',
        sender: 'self',
        timestamp: new Date()
      }]);
    } catch (error) {
      console.error('Failed to initialize media:', error);
    }
  };

  const handleFindPartner = () => {
    if (!localStream) return;

    setShowLoadingModal(true);
    sendMessage({ type: 'find-partner' });
  };

  const handleEndChat = () => {
    sendMessage({ type: 'end-chat' });
    handlePartnerDisconnected();
  };

  const handlePartnerDisconnected = () => {
    setIsConnected(false);
    setShowLoadingModal(false);
    cleanup();
    setMessages(prev => [...prev, {
      id: Date.now().toString(),
      text: 'Partner disconnected',
      sender: 'self',
      timestamp: new Date()
    }]);
  };

  const handleSendMessage = (message: string) => {
    const newMessage = {
      id: Date.now().toString(),
      text: message,
      sender: 'self' as const,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newMessage]);
    sendMessage({ type: 'chat-message', message });
  };

  const connectionStatus = wsConnected && isConnected ? 'connected' : 
                          wsConnected ? 'disconnected' : 'connecting';

  // Show loading screen while detecting device
  if (deviceLoading || !deviceInfo || !layoutConfig) {
    return (
      <div className="min-h-screen gradient-bg flex items-center justify-center">
        <div className="text-center text-white">
          <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full mx-auto mb-4 flex items-center justify-center pulse-glow float-animation">
            <Video className="w-10 h-10" />
          </div>
          <h2 className="text-xl font-semibold mb-2">Analyzing your device...</h2>
          <div className="spinner mx-auto"></div>
        </div>
      </div>
    );
  }

  // Common props for all layouts
  const layoutProps = {
    deviceInfo,
    layoutConfig,
    localStream,
    remoteStream,
    isVideoEnabled,
    isAudioEnabled,
    onToggleVideo: toggleVideo,
    onToggleAudio: toggleAudio,
    onFindPartner: handleFindPartner,
    onEndChat: handleEndChat,
    hasPartner: isConnected,
    messages,
    onSendMessage: handleSendMessage
  };

  // Render adaptive layout based on device type
  const renderLayout = () => {
    if (isPhone) {
      return <MobileLayout {...layoutProps} />;
    }

    if (isTablet) {
      return <TabletLayout {...layoutProps} />;
    }

    return <DesktopLayout {...layoutProps} />;
  };

  return (
    <>
      {renderLayout()}

      {/* AI Swarm Intelligence Panel - Only for desktop */}
      {isDesktop && <SwarmIntelligencePanel />}

      {/* Modals */}
      <PermissionModal
        isOpen={showPermissionModal}
        onGranted={handlePermissionGranted}
        onDenied={() => setShowPermissionModal(false)}
      />

      <LoadingModal
        isOpen={showLoadingModal}
        onCancel={() => setShowLoadingModal(false)}
      />
    </>
  );
}