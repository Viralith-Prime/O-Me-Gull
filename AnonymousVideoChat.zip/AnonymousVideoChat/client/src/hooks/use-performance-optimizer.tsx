import { useState, useEffect, useCallback } from 'react';

interface PerformanceMetrics {
  fps: number;
  memoryUsage: number;
  connectionQuality: 'poor' | 'fair' | 'good' | 'excellent';
  latency: number;
  bandwidth: number;
  cpuUsage: number;
  batteryLevel?: number;
}

interface OptimizationSettings {
  videoQuality: 'low' | 'medium' | 'high' | 'auto';
  frameRate: number;
  bitrate: number;
  audioQuality: 'low' | 'medium' | 'high';
  enableAdaptiveBitrate: boolean;
  enableHardwareAcceleration: boolean;
}

export function usePerformanceOptimizer() {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    fps: 60,
    memoryUsage: 0,
    connectionQuality: 'excellent',
    latency: 0,
    bandwidth: 0,
    cpuUsage: 0
  });

  const [optimizationSettings, setOptimizationSettings] = useState<OptimizationSettings>({
    videoQuality: 'auto',
    frameRate: 30,
    bitrate: 1000000, // 1 Mbps
    audioQuality: 'high',
    enableAdaptiveBitrate: true,
    enableHardwareAcceleration: true
  });

  const measurePerformance = useCallback(() => {
    const now = performance.now();

    // Measure memory usage
    if ('memory' in performance) {
      const memory = (performance as any).memory;
      setMetrics(prev => ({
        ...prev,
        memoryUsage: (memory.usedJSHeapSize / memory.jsHeapSizeLimit) * 100
      }));
    }

    // Measure FPS
    let frameCount = 0;
    const startTime = now;

    const measureFPS = () => {
      frameCount++;
      if (performance.now() - startTime < 1000) {
        requestAnimationFrame(measureFPS);
      } else {
        setMetrics(prev => ({ ...prev, fps: frameCount }));
      }
    };
    requestAnimationFrame(measureFPS);

    // Measure battery (if available)
    if ('getBattery' in navigator) {
      (navigator as any).getBattery().then((battery: any) => {
        setMetrics(prev => ({ ...prev, batteryLevel: battery.level * 100 }));
      });
    }
  }, []);

  const optimizeWebRTC = useCallback((peerConnection: RTCPeerConnection) => {
    console.log('🚀 AI Swarm: Optimizing WebRTC connection...');

    // Get current performance metrics
    const { fps, memoryUsage, connectionQuality, batteryLevel } = metrics;

    // Dynamic quality adjustment based on performance
    let targetBitrate = optimizationSettings.bitrate;
    let targetFrameRate = optimizationSettings.frameRate;

    // Battery optimization
    if (batteryLevel && batteryLevel < 20) {
      targetBitrate *= 0.5; // Reduce bitrate by 50% on low battery
      targetFrameRate = Math.min(targetFrameRate, 15);
    }

    // Performance-based optimization
    if (memoryUsage > 80) {
      targetBitrate *= 0.7; // Reduce bitrate if memory usage is high
      targetFrameRate = Math.min(targetFrameRate, 20);
    }

    if (fps < 20) {
      targetBitrate *= 0.6; // Reduce bitrate if FPS is low
      targetFrameRate = Math.min(targetFrameRate, 15);
    }

    // Connection quality optimization
    switch (connectionQuality) {
      case 'poor':
        targetBitrate = Math.min(targetBitrate, 300000); // 300 Kbps max
        targetFrameRate = 10;
        break;
      case 'fair':
        targetBitrate = Math.min(targetBitrate, 500000); // 500 Kbps max
        targetFrameRate = 15;
        break;
      case 'good':
        targetBitrate = Math.min(targetBitrate, 1000000); // 1 Mbps max
        targetFrameRate = 25;
        break;
      case 'excellent':
        // Use original settings
        break;
    }

    // Apply optimizations to WebRTC
    const senders = peerConnection.getSenders();
    senders.forEach(sender => {
      if (sender.track?.kind === 'video') {
        const params = sender.getParameters();
        if (params.encodings && params.encodings.length > 0) {
          params.encodings[0].maxBitrate = targetBitrate;
          params.encodings[0].maxFramerate = targetFrameRate;

          // Apply hardware acceleration if available
          if (optimizationSettings.enableHardwareAcceleration) {
            params.encodings[0].scalabilityMode = 'L1T1';
          }

          sender.setParameters(params).catch(err => 
            console.warn('Failed to apply WebRTC optimization:', err)
          );
        }
      }
    });

    console.log('✅ AI Swarm: WebRTC optimization applied', {
      targetBitrate: targetBitrate / 1000 + ' Kbps',
      targetFrameRate,
      connectionQuality,
      memoryUsage: memoryUsage.toFixed(1) + '%',
      batteryLevel: batteryLevel ? batteryLevel.toFixed(0) + '%' : 'N/A'
    });

  }, [metrics, optimizationSettings]);

  const optimizeForDevice = useCallback((deviceType: string) => {
    console.log('📱 AI Swarm: Optimizing for device type:', deviceType);

    switch (deviceType) {
      case 'phone':
        setOptimizationSettings(prev => ({
          ...prev,
          videoQuality: 'medium',
          frameRate: 20,
          bitrate: 500000, // 500 Kbps for mobile
          audioQuality: 'medium'
        }));
        break;

      case 'tablet':
        setOptimizationSettings(prev => ({
          ...prev,
          videoQuality: 'high',
          frameRate: 25,
          bitrate: 800000, // 800 Kbps for tablet
          audioQuality: 'high'
        }));
        break;

      case 'desktop':
      case 'laptop':
        setOptimizationSettings(prev => ({
          ...prev,
          videoQuality: 'high',
          frameRate: 30,
          bitrate: 1500000, // 1.5 Mbps for desktop
          audioQuality: 'high'
        }));
        break;
    }
  }, []);

  useEffect(() => {
    const interval = setInterval(measurePerformance, 5000);
    return () => clearInterval(interval);
  }, [measurePerformance]);

  return { 
    metrics, 
    optimizationSettings,
    optimizeWebRTC, 
    optimizeForDevice,
    measurePerformance
  };
}