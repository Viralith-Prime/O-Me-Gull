import { useState, useEffect, useCallback } from 'react';

export interface DeviceInfo {
  type: 'phone' | 'tablet' | 'desktop' | 'laptop';
  brand: string;
  model: string;
  os: string;
  osVersion: string;
  browser: string;
  browserVersion: string;
  screenSize: 'small' | 'medium' | 'large' | 'xlarge';
  orientation: 'portrait' | 'landscape';
  hasTouch: boolean;
  pixelDensity: number;
  viewportWidth: number;
  viewportHeight: number;
  deviceWidth: number;
  deviceHeight: number;
  confidence: number; // 0-100% confidence in device detection
}

export interface LayoutConfig {
  showChat: boolean;
  chatPosition: 'sidebar' | 'modal' | 'bottom' | 'hidden';
  videoLayout: 'grid' | 'main-pip' | 'fullscreen';
  controlsPosition: 'bottom' | 'overlay' | 'floating';
  remoteVideoSize: number; // percentage of screen
  localVideoSize: number; // percentage of screen
  localVideoPosition: 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left';
}

// Advanced device detection patterns
const DEVICE_PATTERNS = {
  // iOS devices
  iPhone: [
    { pattern: /iPhone.*OS\s+(\d+)/, type: 'phone' as const, confidence: 95 },
    { pattern: /iPhone14/, model: 'iPhone 14', confidence: 98 },
    { pattern: /iPhone13/, model: 'iPhone 13', confidence: 98 },
    { pattern: /iPhone12/, model: 'iPhone 12', confidence: 98 },
    { pattern: /iPhone11/, model: 'iPhone 11', confidence: 98 },
    { pattern: /iPhoneX/, model: 'iPhone X', confidence: 98 },
    { pattern: /iPhone\s*SE/, model: 'iPhone SE', confidence: 98 },
  ],
  iPad: [
    { pattern: /iPad.*OS\s+(\d+)/, type: 'tablet' as const, confidence: 95 },
    { pattern: /iPad\s*Pro/, model: 'iPad Pro', confidence: 98 },
    { pattern: /iPad\s*Air/, model: 'iPad Air', confidence: 98 },
    { pattern: /iPad\s*Mini/, model: 'iPad Mini', confidence: 98 },
  ],

  // Android devices
  Samsung: [
    { pattern: /SM-G\d{3}/, brand: 'Samsung', type: 'phone' as const, confidence: 90 },
    { pattern: /SM-T\d{3}/, brand: 'Samsung', type: 'tablet' as const, confidence: 90 },
    { pattern: /Galaxy\s*S(\d+)/, model: 'Galaxy S$1', confidence: 95 },
    { pattern: /Galaxy\s*Note/, model: 'Galaxy Note', confidence: 95 },
    { pattern: /Galaxy\s*Tab/, model: 'Galaxy Tab', type: 'tablet' as const, confidence: 95 },
  ],
  Google: [
    { pattern: /Pixel\s*(\d+)/, brand: 'Google', model: 'Pixel $1', type: 'phone' as const, confidence: 95 },
    { pattern: /Nexus\s*(\d+)/, brand: 'Google', model: 'Nexus $1', confidence: 90 },
  ],
  OnePlus: [
    { pattern: /OnePlus\s*(\d+)/, brand: 'OnePlus', model: 'OnePlus $1', type: 'phone' as const, confidence: 95 },
  ],

  // Desktop/Laptop indicators
  Windows: [
    { pattern: /Windows\s+NT\s+10/, os: 'Windows 10', confidence: 90 },
    { pattern: /Windows\s+NT\s+11/, os: 'Windows 11', confidence: 90 },
  ],
  Mac: [
    { pattern: /Macintosh.*Intel/, type: 'laptop' as const, os: 'macOS', confidence: 85 },
    { pattern: /Macintosh.*PPC/, type: 'desktop' as const, os: 'macOS', confidence: 85 },
  ],
  Linux: [
    { pattern: /Linux\s+x86_64/, os: 'Linux', confidence: 80 },
    { pattern: /Ubuntu/, os: 'Ubuntu', confidence: 85 },
  ]
};

function detectDeviceFromUserAgent(userAgent: string): Partial<DeviceInfo> {
  const result: Partial<DeviceInfo> = {
    brand: 'Unknown',
    model: 'Unknown',
    os: 'Unknown',
    osVersion: 'Unknown',
    confidence: 0
  };

  let maxConfidence = 0;

  // Check all device patterns
  Object.entries(DEVICE_PATTERNS).forEach(([category, patterns]) => {
    patterns.forEach(pattern => {
      const match = userAgent.match(pattern.pattern);
      if (match && pattern.confidence > maxConfidence) {
        maxConfidence = pattern.confidence;

        if (pattern.type) result.type = pattern.type;
        if (pattern.brand) result.brand = pattern.brand;
        if (pattern.model) {
          result.model = pattern.model.replace(/\$(\d+)/g, (_, num) => match[parseInt(num)] || '');
        }
        if (pattern.os) result.os = pattern.os;

        result.confidence = pattern.confidence;

        // Extract OS version if available
        if (match[1]) {
          result.osVersion = match[1];
        }
      }
    });
  });

  // Fallback brand detection
  if (result.brand === 'Unknown') {
    if (userAgent.includes('iPhone') || userAgent.includes('iPad')) {
      result.brand = 'Apple';
    } else if (userAgent.includes('Samsung')) {
      result.brand = 'Samsung';
    } else if (userAgent.includes('Pixel')) {
      result.brand = 'Google';
    }
  }

  return result;
}

function getScreenSizeCategory(width: number, height: number): DeviceInfo['screenSize'] {
  const maxDimension = Math.max(width, height);

  if (maxDimension <= 480) return 'small';      // Phone
  if (maxDimension <= 768) return 'medium';     // Large phone / small tablet
  if (maxDimension <= 1024) return 'large';     // Tablet
  return 'xlarge';                              // Desktop
}

function detectDeviceType(info: Partial<DeviceInfo>): DeviceInfo['type'] {
  const { viewportWidth = 0, viewportHeight = 0, hasTouch = false } = info;
  const maxDimension = Math.max(viewportWidth, viewportHeight);
  const minDimension = Math.min(viewportWidth, viewportHeight);

  // If already detected from user agent, trust it with high confidence
  if (info.type && info.confidence && info.confidence > 85) {
    return info.type;
  }

  // Screen size based detection
  if (maxDimension <= 480) return 'phone';
  if (maxDimension <= 768 && hasTouch) return 'phone'; // Large phone
  if (maxDimension <= 1024 && hasTouch) return 'tablet';
  if (maxDimension <= 1366 && !hasTouch) return 'laptop';

  return hasTouch ? 'tablet' : 'desktop';
}

function generateLayoutConfig(device: DeviceInfo): LayoutConfig {
  const { type, orientation, viewportWidth, viewportHeight, brand } = device;

  // Device-specific optimizations
  const isIOS = brand === 'Apple';
  const isAndroid = brand === 'Samsung' || brand === 'Google' || brand === 'OnePlus';

  switch (type) {
    case 'phone':
      return {
        showChat: false,
        chatPosition: 'modal',
        videoLayout: 'fullscreen',
        controlsPosition: 'overlay',
        remoteVideoSize: isIOS ? 95 : 90, // iOS needs more space
        localVideoSize: 0, // Hidden by default on mobile
        localVideoPosition: 'bottom-right'
      };

    case 'tablet':
      if (orientation === 'portrait') {
        // Portrait mode - phone-like layout with tablet optimizations
        return {
          showChat: false,
          chatPosition: 'modal',
          videoLayout: 'fullscreen',
          controlsPosition: 'overlay',
          remoteVideoSize: 85,
          localVideoSize: 15, // Show small local video on tablets
          localVideoPosition: 'bottom-right'
        };
      } else {
        // Landscape mode - optimized tablet layout
        return {
          showChat: true,
          chatPosition: 'sidebar',
          videoLayout: 'main-pip',
          controlsPosition: 'bottom',
          remoteVideoSize: 70,
          localVideoSize: 20,
          localVideoPosition: 'bottom-left'
        };
      }

    case 'laptop':
    case 'desktop':
    default:
      return {
        showChat: true,
        chatPosition: 'sidebar',
        videoLayout: 'grid',
        controlsPosition: 'bottom',
        remoteVideoSize: 50,
        localVideoSize: 50,
        localVideoPosition: 'bottom-right'
      };
  }
}

export function useDeviceManager() {
  const [deviceInfo, setDeviceInfo] = useState<DeviceInfo | null>(null);
  const [layoutConfig, setLayoutConfig] = useState<LayoutConfig | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const detectDevice = useCallback(() => {
    try {
      const userAgent = navigator.userAgent;
      const hasTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
      const pixelDensity = window.devicePixelRatio || 1;

      // Get viewport dimensions
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;

      // Get device dimensions
      const deviceWidth = screen.width;
      const deviceHeight = screen.height;

      // Detect orientation
      const orientation = viewportWidth > viewportHeight ? 'landscape' : 'portrait';

      // Get screen size category
      const screenSize = getScreenSizeCategory(viewportWidth, viewportHeight);

      // Extract device info from user agent
      const uaInfo = detectDeviceFromUserAgent(userAgent);

      // Browser detection
      let browser = 'Unknown';
      let browserVersion = 'Unknown';

      if (userAgent.includes('Chrome')) {
        browser = 'Chrome';
        const match = userAgent.match(/Chrome\/(\d+)/);
        browserVersion = match ? match[1] : 'Unknown';
      } else if (userAgent.includes('Firefox')) {
        browser = 'Firefox';
        const match = userAgent.match(/Firefox\/(\d+)/);
        browserVersion = match ? match[1] : 'Unknown';
      } else if (userAgent.includes('Safari')) {
        browser = 'Safari';
        const match = userAgent.match(/Version\/(\d+)/);
        browserVersion = match ? match[1] : 'Unknown';
      }

      const info: DeviceInfo = {
        type: detectDeviceType({ ...uaInfo, viewportWidth, viewportHeight, hasTouch }),
        brand: uaInfo.brand || 'Unknown',
        model: uaInfo.model || 'Unknown',
        os: uaInfo.os || 'Unknown',
        osVersion: uaInfo.osVersion || 'Unknown',
        browser,
        browserVersion,
        screenSize,
        orientation,
        hasTouch,
        pixelDensity,
        viewportWidth,
        viewportHeight,
        deviceWidth,
        deviceHeight,
        confidence: uaInfo.confidence || 70
      };

      setDeviceInfo(info);
      setLayoutConfig(generateLayoutConfig(info));
      setIsLoading(false);

      console.log('🔍 Device Detection Results:', info);

    } catch (error) {
      console.error('Device detection failed:', error);
      setIsLoading(false);
    }
  }, []);

  // Handle orientation changes
  const handleOrientationChange = useCallback(() => {
    setTimeout(detectDevice, 100); // Small delay to let dimensions update
  }, [detectDevice]);

  // Handle resize events
  const handleResize = useCallback(() => {
    if (deviceInfo) {
      const newOrientation = window.innerWidth > window.innerHeight ? 'landscape' : 'portrait';
      const newViewportWidth = window.innerWidth;
      const newViewportHeight = window.innerHeight;

      if (newOrientation !== deviceInfo.orientation || 
          Math.abs(newViewportWidth - deviceInfo.viewportWidth) > 50) {
        detectDevice();
      }
    }
  }, [deviceInfo, detectDevice]);

  useEffect(() => {
    detectDevice();

    // Listen for orientation changes
    window.addEventListener('orientationchange', handleOrientationChange);
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('orientationchange', handleOrientationChange);
      window.removeEventListener('resize', handleResize);
    };
  }, []); // Empty dependency array to run only once

  const updateLayoutConfig = useCallback((updates: Partial<LayoutConfig>) => {
    setLayoutConfig(prev => prev ? { ...prev, ...updates } : null);
  }, []);

  const isPhone = deviceInfo?.type === 'phone';
  const isTablet = deviceInfo?.type === 'tablet';
  const isDesktop = deviceInfo?.type === 'desktop' || deviceInfo?.type === 'laptop';
  const isMobile = isPhone || (isTablet && deviceInfo?.orientation === 'portrait');

  return {
    deviceInfo,
    layoutConfig,
    isLoading,
    isPhone,
    isTablet,
    isDesktop,
    isMobile,
    updateLayoutConfig,
    refetch: detectDevice
  };
}