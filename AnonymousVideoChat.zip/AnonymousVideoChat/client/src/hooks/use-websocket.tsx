import { useState, useEffect, useRef, useCallback } from "react";

interface WebSocketMessage {
  type: string;
  [key: string]: any;
}

interface UseWebSocketOptions {
  onOffer?: (offer: RTCSessionDescriptionInit) => void;
  onAnswer?: (answer: RTCSessionDescriptionInit) => void;
  onIceCandidate?: (candidate: RTCIceCandidateInit) => void;
  onPartnerFound?: () => void;
  onPartnerLeft?: () => void;
  onChatMessage?: (message: string) => void;
  onMessage?: (data: WebSocketMessage) => void;
  onConnect?: () => void;
  onDisconnect?: () => void;
}

// Global WebSocket instance to prevent multiple connections
let globalWS: WebSocket | null = null;
let globalConnectionStatus = false;
let globalListeners: Set<(data: WebSocketMessage) => void> = new Set();

export function useWebSocket(options: UseWebSocketOptions = {}) {
  const [isConnected, setIsConnected] = useState(globalConnectionStatus);
  const [error, setError] = useState<string | null>(null);
  const optionsRef = useRef(options);
  optionsRef.current = options;

  const sendMessage = useCallback((message: WebSocketMessage) => {
    if (globalWS && globalWS.readyState === WebSocket.OPEN) {
      console.log('Sending WebSocket message:', message);
      globalWS.send(JSON.stringify(message));
    } else {
      console.warn('WebSocket is not connected, cannot send message:', message);
    }
  }, []);

  const connectWebSocket = useCallback(() => {
    if (globalWS && (globalWS.readyState === WebSocket.CONNECTING || globalWS.readyState === WebSocket.OPEN)) {
      return;
    }

    try {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;

      console.log('Creating global WebSocket connection to:', wsUrl);
      globalWS = new WebSocket(wsUrl);

      globalWS.onopen = () => {
        console.log('Global WebSocket connected successfully');
        globalConnectionStatus = true;
        setIsConnected(true);
        setError(null);
        optionsRef.current.onConnect?.();
      };

      globalWS.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          console.log('Global WebSocket message received:', data);

          // Handle specific message types for all listeners
          globalListeners.forEach(listener => {
            // Call the listener with the full data
            listener(data);
          });
        } catch (err) {
          console.error('Failed to parse WebSocket message:', err);
        }
      };

      globalWS.onclose = (event) => {
        console.log('Global WebSocket closed:', event.code, event.reason, event.wasClean);
        globalConnectionStatus = false;
        setIsConnected(false);
        optionsRef.current.onDisconnect?.();

        // Only attempt reconnection if it wasn't a clean close
        if (!event.wasClean && event.code !== 1000) {
          setTimeout(() => {
            connectWebSocket();
          }, 2000);
        }
        globalWS = null;
      };

      globalWS.onerror = (error) => {
        console.error('Global WebSocket error:', error);
        setError('Connection failed');

        // Attempt to reconnect after a delay
        setTimeout(() => {
          if (globalWS?.readyState === WebSocket.CLOSED) {
            connectWebSocket();
          }
        }, 3000);
      };
    } catch (err) {
      console.error('Failed to create WebSocket connection:', err);
      setError('Failed to connect');
    }
  }, []);

  useEffect(() => {
    // Add this component's message handler to global listeners
    if (optionsRef.current.onMessage) {
      globalListeners.add(optionsRef.current.onMessage);
    }

    // Connect if not already connected
    if (!globalWS) {
      connectWebSocket();
    } else if (globalWS.readyState === WebSocket.OPEN) {
      setIsConnected(true);
    }

    // Listen for WebRTC events to forward to WebSocket
    const handleSendOffer = (event: CustomEvent) => {
      sendMessage({ type: 'offer', offer: event.detail });
    };

    const handleSendAnswer = (event: CustomEvent) => {
      sendMessage({ type: 'answer', answer: event.detail });
    };

    const handleSendIceCandidate = (event: CustomEvent) => {
      sendMessage({ type: 'ice-candidate', candidate: event.detail });
    };

    window.addEventListener('send-offer', handleSendOffer as EventListener);
    window.addEventListener('send-answer', handleSendAnswer as EventListener);
    window.addEventListener('send-ice-candidate', handleSendIceCandidate as EventListener);

    return () => {
      // Remove this component's message handler from global listeners
      if (optionsRef.current.onMessage) {
        globalListeners.delete(optionsRef.current.onMessage);
      }

      window.removeEventListener('send-offer', handleSendOffer as EventListener);
      window.removeEventListener('send-answer', handleSendAnswer as EventListener);
      window.removeEventListener('send-ice-candidate', handleSendIceCandidate as EventListener);
    };
  }, [sendMessage, connectWebSocket]);

  return {
    isConnected,
    error,
    sendMessage,
    disconnect: () => {
      if (globalWS) {
        globalWS.close();
        globalWS = null;
        globalConnectionStatus = false;
        setIsConnected(false);
      }
    }
  };
}