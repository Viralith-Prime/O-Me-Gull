import { useState, useRef, useCallback } from "react";
import { usePerformanceOptimizer } from './use-performance-optimizer';

const STUN_SERVERS = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' }
  ]
};

export function useWebRTC() {
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);

  const peerConnection = useRef<RTCPeerConnection | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);

  const { optimizeWebRTC, metrics } = usePerformanceOptimizer();

  const initializePeerConnection = useCallback(() => {
    if (peerConnection.current) return;

    peerConnection.current = new RTCPeerConnection(STUN_SERVERS);

    peerConnection.current.onicecandidate = (event) => {
      if (event.candidate) {
        // Send ICE candidate to peer via WebSocket
        window.dispatchEvent(new CustomEvent('send-ice-candidate', {
          detail: event.candidate
        }));
      }
    };

    peerConnection.current.ontrack = (event) => {
      setRemoteStream(event.streams[0]);
      setIsConnected(true);
    };

    peerConnection.current.onconnectionstatechange = () => {
      const state = peerConnection.current?.connectionState;
      if (state === 'disconnected' || state === 'failed' || state === 'closed') {
        setIsConnected(false);
        setRemoteStream(null);
      }
    };
  }, []);

  const initializeMedia = useCallback(async () => {
    try {
      // Request camera permissions first
      const permissions = await navigator.permissions.query({ name: 'camera' as PermissionName });
      console.log('📹 Camera permission status:', permissions.state);

      // Enhanced constraints for better mobile compatibility
      const constraints = {
        video: {
          width: { 
            min: 320, 
            ideal: window.innerWidth > 768 ? 1280 : 640, 
            max: window.innerWidth > 768 ? 1920 : 1280 
          },
          height: { 
            min: 240, 
            ideal: window.innerWidth > 768 ? 720 : 480, 
            max: window.innerWidth > 768 ? 1080 : 720 
          },
          frameRate: { ideal: 30, max: 60 },
          facingMode: 'user',
          aspectRatio: 16/9
        },
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          sampleRate: 44100
        }
      };

      console.log('📹 Requesting camera access with constraints:', constraints);
      
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      
      console.log('📹 Camera stream obtained:', {
        videoTracks: stream.getVideoTracks().length,
        audioTracks: stream.getAudioTracks().length,
        videoSettings: stream.getVideoTracks()[0]?.getSettings()
      });

      setLocalStream(stream);
      setIsVideoEnabled(true);
      setIsAudioEnabled(true);
      
      initializePeerConnection();

      // Add tracks to peer connection
      if (peerConnection.current) {
        stream.getTracks().forEach(track => {
          console.log('📹 Adding track to peer connection:', track.kind);
          peerConnection.current?.addTrack(track, stream);
        });

        // Apply initial optimization
        optimizeWebRTC(peerConnection.current);
      }

      return stream;
    } catch (error) {
      console.error('❌ Failed to get user media:', error);
      
      // Fallback with minimal constraints
      try {
        console.log('📹 Trying fallback camera access...');
        const fallbackStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'user' },
          audio: true
        });
        
        setLocalStream(fallbackStream);
        setIsVideoEnabled(true);
        setIsAudioEnabled(true);
        
        console.log('✅ Fallback camera access successful');
        return fallbackStream;
      } catch (fallbackError) {
        console.error('❌ Fallback camera access failed:', fallbackError);
        throw fallbackError;
      }
    }
  }, [initializePeerConnection, optimizeWebRTC]);

  const createOffer = useCallback(async () => {
    if (!peerConnection.current || !localStream) return;

    try {
      const offer = await peerConnection.current.createOffer();
      await peerConnection.current.setLocalDescription(offer);

      // Send offer to peer via WebSocket
      window.dispatchEvent(new CustomEvent('send-offer', {
        detail: offer
      }));
    } catch (error) {
      console.error('Error creating offer:', error);
    }
  }, [localStream]);

  const createAnswer = useCallback(async (offer: RTCSessionDescriptionInit) => {
    if (!peerConnection.current) return;

    try {
      await peerConnection.current.setRemoteDescription(offer);
      const answer = await peerConnection.current.createAnswer();
      await peerConnection.current.setLocalDescription(answer);

      // Send answer to peer via WebSocket
      window.dispatchEvent(new CustomEvent('send-answer', {
        detail: answer
      }));
    } catch (error) {
      console.error('Error creating answer:', error);
    }
  }, []);

  const setRemoteDescription = useCallback(async (answer: RTCSessionDescriptionInit) => {
    if (!peerConnection.current) return;

    try {
      await peerConnection.current.setRemoteDescription(answer);
    } catch (error) {
      console.error('Error setting remote description:', error);
    }
  }, []);

  const addIceCandidate = useCallback(async (candidate: RTCIceCandidateInit) => {
    if (!peerConnection.current) return;

    try {
      await peerConnection.current.addIceCandidate(candidate);
    } catch (error) {
      console.error('Error adding ICE candidate:', error);
    }
  }, []);

  const toggleVideo = useCallback(() => {
    if (!localStream) return;

    const videoTrack = localStream.getVideoTracks()[0];
    if (videoTrack) {
      const newEnabled = !videoTrack.enabled;
      videoTrack.enabled = newEnabled;
      setIsVideoEnabled(newEnabled);
      
      // Update the peer connection with the new track state
      if (peerConnection.current) {
        const sender = peerConnection.current.getSenders().find(s => 
          s.track && s.track.kind === 'video'
        );
        if (sender && sender.track) {
          sender.track.enabled = newEnabled;
        }
      }
    }
  }, [localStream]);

  const toggleAudio = useCallback(() => {
    if (!localStream) return;

    const audioTrack = localStream.getAudioTracks()[0];
    if (audioTrack) {
      audioTrack.enabled = !audioTrack.enabled;
      setIsAudioEnabled(audioTrack.enabled);
    }
  }, [localStream]);

  const cleanup = useCallback(() => {
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }

    if (peerConnection.current) {
      peerConnection.current.close();
      peerConnection.current = null;
    }

    setRemoteStream(null);
    setIsConnected(false);
  }, [localStream]);

  return {
    localStream,
    remoteStream,
    isConnected,
    isVideoEnabled,
    isAudioEnabled,
    initializeMedia,
    toggleVideo,
    toggleAudio,
    createOffer,
    createAnswer,
    addIceCandidate,
    setRemoteDescription,
    cleanup
  };
}