
import { useState, useEffect } from 'react';
import { Activity, Shield, Eye, EyeOff, Zap, TestTube } from 'lucide-react';

interface SwarmAgent {
  id: string;
  name: string;
  role: string;
  status: 'active' | 'processing' | 'idle' | 'error';
  confidence: number;
}

interface SwarmIntelligence {
  performanceMetrics: {
    fps: number;
    latency: number;
    memoryUsage: number;
    connectionQuality: string;
  };
  securityStatus: {
    threats: number;
    protectionLevel: number;
  };
  optimizationSuggestions: Array<{
    action: string;
    confidence: number;
    priority: string;
  }>;
  deviceAnalysis: {
    deviceType: string;
    optimizations: string[];
    compatibility: number;
  };
}

export function SwarmIntelligencePanel() {
  const [isVisible, setIsVisible] = useState(false);
  const [intelligence, setIntelligence] = useState<SwarmIntelligence | null>(null);
  const [agents, setAgents] = useState<SwarmAgent[]>([]);
  const [testStatus, setTestStatus] = useState<any>(null);

  useEffect(() => {
    const fetchSwarmData = async () => {
      try {
        const response = await fetch('/api/swarm/status');
        const data = await response.json();
        setIntelligence(data.intelligence);
        setAgents(data.agents);
      } catch (error) {
        console.error('Failed to fetch swarm data:', error);
      }
    };

    const fetchTestData = async () => {
      try {
        const response = await fetch('/api/test-suite/quick-status');
        const data = await response.json();
        setTestStatus(data);
      } catch (error) {
        console.error('Failed to fetch test data:', error);
      }
    };

    fetchSwarmData();
    fetchTestData();
    const interval = setInterval(() => {
      fetchSwarmData();
      fetchTestData();
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const triggerOptimization = async (command: string) => {
    try {
      await fetch('/api/swarm/optimize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command })
      });
    } catch (error) {
      console.error('Failed to trigger optimization:', error);
    }
  };

  return (
    <div className="fixed top-4 left-4 z-50">
      {/* Toggle Button */}
      <button
        onClick={() => setIsVisible(!isVisible)}
        className="glass-dark rounded-lg p-3 hover:bg-white/10 transition-colors"
      >
        {isVisible ? <EyeOff className="w-5 h-5 text-purple-400" /> : <Eye className="w-5 h-5 text-purple-400" />}
      </button>

      {/* Swarm Panel */}
      {isVisible && (
        <div className="mt-3 glass-transparent rounded-lg p-4 w-80 backdrop-blur-lg">
          <div className="flex items-center space-x-2 mb-4">
            <Zap className="w-5 h-5 text-purple-400" />
            <h3 className="text-white font-semibold">AI Swarm Intelligence</h3>
          </div>

          {intelligence && (
            <>
              {/* Performance Metrics */}
              <div className="mb-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Activity className="w-4 h-4 text-green-400" />
                  <span className="text-sm font-medium">Performance</span>
                </div>
                <div className="text-xs space-y-1 text-white/80">
                  <div>FPS: {intelligence.performanceMetrics.fps.toFixed(1)}</div>
                  <div>Latency: {intelligence.performanceMetrics.latency.toFixed(0)}ms</div>
                  <div>Memory: {intelligence.performanceMetrics.memoryUsage.toFixed(1)}%</div>
                  <div className={`px-2 py-1 rounded text-xs inline-block ${
                    intelligence.performanceMetrics.connectionQuality === 'excellent' ? 'bg-green-500/20 text-green-300' :
                    intelligence.performanceMetrics.connectionQuality === 'good' ? 'bg-yellow-500/20 text-yellow-300' :
                    'bg-red-500/20 text-red-300'
                  }`}>
                    {intelligence.performanceMetrics.connectionQuality}
                  </div>
                </div>
              </div>

              {/* Security Status */}
              <div className="mb-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Shield className="w-4 h-4 text-blue-400" />
                  <span className="text-sm font-medium">Security</span>
                </div>
                <div className="text-xs space-y-1 text-white/80">
                  <div>Threats: {intelligence.securityStatus.threats}/10</div>
                  <div>Protection: {intelligence.securityStatus.protectionLevel.toFixed(1)}%</div>
                </div>
              </div>

              {/* Test Suite Status */}
              {testStatus && (
                <div className="mb-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <TestTube className="w-4 h-4 text-cyan-400" />
                    <span className="text-sm font-medium">Test Suite</span>
                  </div>
                  <div className="text-xs space-y-1 text-white/80">
                    <div className={`px-2 py-1 rounded text-xs inline-block ${
                      testStatus.status === 'excellent' ? 'bg-green-500/20 text-green-300' :
                      testStatus.status === 'good' ? 'bg-yellow-500/20 text-yellow-300' :
                      testStatus.status === 'warning' ? 'bg-orange-500/20 text-orange-300' :
                      'bg-red-500/20 text-red-300'
                    }`}>
                      {testStatus.status}
                    </div>
                    <div>Pass Rate: {testStatus.passRate.toFixed(1)}%</div>
                    <div>Critical Issues: {testStatus.criticalIssues}</div>
                  </div>
                </div>
              )}

              {/* Agent Status */}
              <div className="mb-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Zap className="w-4 h-4 text-purple-400" />
                  <span className="text-sm font-medium">Agents</span>
                </div>
                <div className="space-y-1">
                  {agents.map(agent => (
                    <div key={agent.id} className="text-xs flex justify-between items-center">
                      <span className="truncate">{agent.name}</span>
                      <div className="flex items-center space-x-2">
                        <span className={`w-2 h-2 rounded-full ${
                          agent.status === 'active' ? 'bg-green-400' :
                          agent.status === 'processing' ? 'bg-yellow-400' :
                          'bg-gray-400'
                        }`} />
                        <span className="text-white/60">{agent.confidence.toFixed(0)}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Optimization Suggestions */}
              {intelligence.optimizationSuggestions.length > 0 && (
                <div className="mb-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <Eye className="w-4 h-4 text-yellow-400" />
                    <span className="text-sm font-medium">Suggestions</span>
                  </div>
                  <div className="space-y-2">
                    {intelligence.optimizationSuggestions.slice(0, 3).map((suggestion, idx) => (
                      <div key={idx} className="text-xs">
                        <div className="flex justify-between items-start">
                          <span className="text-white/80 text-xs">{suggestion.action}</span>
                          <span className="text-purple-300 text-xs">{suggestion.confidence}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Quick Actions */}
              <div className="flex space-x-2">
                <button
                  onClick={() => triggerOptimization('optimize-performance')}
                  className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded text-xs hover:bg-purple-500/30 transition-colors"
                >
                  Optimize
                </button>
                <button
                  onClick={() => triggerOptimization('security-scan')}
                  className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded text-xs hover:bg-blue-500/30 transition-colors"
                >
                  Scan
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
