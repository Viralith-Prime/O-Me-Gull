import { useEffect, useRef } from "react";
import { Video, VideoOff, Mic, MicOff, SkipForward, X, User } from "lucide-react";
import { Button } from "@/components/ui/button";

interface VideoSectionProps {
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  isVideoEnabled: boolean;
  isAudioEnabled: boolean;
  onToggleVideo: () => void;
  onToggleAudio: () => void;
  onFindPartner: () => void;
  onEndChat: () => void;
  hasPartner: boolean;
}

export function VideoSection({
  localStream,
  remoteStream,
  isVideoEnabled,
  isAudioEnabled,
  onToggleVideo,
  onToggleAudio,
  onFindPartner,
  onEndChat,
  hasPartner
}: VideoSectionProps) {
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  return (
    <div className="flex-1 lg:w-3/5 glass rounded-2xl flex flex-col">
      {/* Video Feeds Container */}
      <div className="flex-1 p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 h-full">
          {/* Partner Video Feed */}
          <div className="relative glass-dark rounded-2xl overflow-hidden aspect-video video-container glow-border">
            {remoteStream ? (
              <video
                ref={remoteVideoRef}
                className="w-full h-full object-cover"
                autoPlay
                playsInline
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-white float-animation">
                  <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full mx-auto mb-4 flex items-center justify-center pulse-glow">
                    <User className="w-10 h-10" />
                  </div>
                  <p className="text-lg opacity-90">Waiting for partner...</p>
                  <div className="mt-4">
                    <div className="spinner mx-auto"></div>
                  </div>
                </div>
              </div>
            )}
            
            {/* Partner Controls Overlay */}
            <div className="absolute bottom-4 left-4">
              <span className="glass text-white px-3 py-1 rounded-full text-sm font-medium">
                Partner
              </span>
            </div>
          </div>

          {/* Self Video Feed */}
          <div className="relative glass-dark rounded-2xl overflow-hidden aspect-video video-container glow-border">
            {localStream ? (
              <video
                ref={localVideoRef}
                className="w-full h-full object-cover scale-x-[-1]"
                autoPlay
                playsInline
                muted
                style={{ 
                  transform: 'scaleX(-1)',
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                  position: 'absolute',
                  top: 0,
                  left: 0
                }}
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center bg-gray-900/50 backdrop-blur-sm">
                <div className="text-center text-white float-animation">
                  <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mx-auto mb-4 flex items-center justify-center pulse-glow">
                    <User className="w-10 h-10" />
                  </div>
                  <p className="text-lg opacity-90">Camera initializing...</p>
                  <div className="mt-4">
                    <div className="spinner mx-auto"></div>
                  </div>
                </div>
              </div>
            )}
            
            {/* Self Video Controls Overlay */}
            <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center">
              <span className="glass text-white px-3 py-1 rounded-full text-sm font-medium">
                You
              </span>
              
              {/* Media Controls */}
              <div className="flex space-x-3">
                <button
                  onClick={onToggleVideo}
                  className={`w-10 h-10 glass rounded-full flex items-center justify-center transition-all btn-modern ${
                    isVideoEnabled ? 'text-white' : 'text-red-400'
                  }`}
                >
                  {isVideoEnabled ? (
                    <Video className="w-4 h-4" />
                  ) : (
                    <VideoOff className="w-4 h-4" />
                  )}
                </button>
                <button
                  onClick={onToggleAudio}
                  className={`w-10 h-10 glass rounded-full flex items-center justify-center transition-all btn-modern ${
                    isAudioEnabled ? 'text-white' : 'text-red-400'
                  }`}
                >
                  {isAudioEnabled ? (
                    <Mic className="w-4 h-4" />
                  ) : (
                    <MicOff className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Action Controls */}
      <div className="p-6 border-t border-white/10">
        <div className="flex justify-center">
          <Button
            onClick={hasPartner ? onEndChat : onFindPartner}
            disabled={!localStream}
            className={`${
              hasPartner 
                ? 'bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600' 
                : 'bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600'
            } text-white px-8 py-4 rounded-xl font-semibold transition-all btn-modern glow-border disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-3 text-lg`}
          >
            {hasPartner ? (
              <>
                <X className="w-5 h-5" />
                <span>End Chat</span>
              </>
            ) : (
              <>
                <SkipForward className="w-5 h-5" />
                <span>Next</span>
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
