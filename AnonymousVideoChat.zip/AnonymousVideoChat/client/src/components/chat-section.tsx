import { useState, useRef, useEffect } from "react";
import { MessageCircle, Send, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface Message {
  id: string;
  text: string;
  sender: 'self' | 'partner';
  timestamp: Date;
}

interface ChatSectionProps {
  messages: Message[];
  onSendMessage: (message: string) => void;
}

export function ChatSection({ messages, onSendMessage }: ChatSectionProps) {
  const [messageInput, setMessageInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (messageInput.trim()) {
      onSendMessage(messageInput.trim());
      setMessageInput("");
    }
  };

  const formatTime = (timestamp: Date) => {
    return timestamp.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  return (
    <div className="w-full lg:w-2/5 glass rounded-2xl flex flex-col">
      {/* Chat Header */}
      <div className="px-6 py-4 border-b border-white/10">
        <h2 className="font-semibold text-white flex items-center space-x-3 float-animation">
          <MessageCircle className="w-5 h-5 text-purple-400" />
          <span>Chat</span>
        </h2>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.length === 0 && (
          <div className="text-center">
            <span className="glass text-white/80 px-4 py-2 rounded-full text-sm shimmer">
              Start a conversation...
            </span>
          </div>
        )}

        {messages.map((message) => {
          if (message.sender === 'self' && message.text === 'Connected to chat') {
            return (
              <div key={message.id} className="text-center message-enter">
                <span className="glass text-green-400 px-4 py-2 rounded-full text-sm">
                  {message.text}
                </span>
              </div>
            );
          }

          if (message.sender === 'self' && message.text === 'Partner disconnected') {
            return (
              <div key={message.id} className="text-center message-enter">
                <span className="glass text-red-400 px-4 py-2 rounded-full text-sm">
                  {message.text}
                </span>
              </div>
            );
          }

          if (message.sender === 'partner') {
            return (
              <div key={message.id} className="flex space-x-3 message-enter">
                <div className="w-8 h-8 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex-shrink-0 flex items-center justify-center pulse-glow">
                  <User className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1">
                  <div className="glass-dark rounded-2xl px-4 py-3 max-w-xs">
                    <p className="text-sm text-white">{message.text}</p>
                  </div>
                  <span className="text-xs text-white/60 mt-2 block">
                    {formatTime(message.timestamp)}
                  </span>
                </div>
              </div>
            );
          }

          return (
            <div key={message.id} className="flex space-x-3 justify-end message-enter">
              <div className="flex-1">
                <div className="bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl px-4 py-3 max-w-xs ml-auto glow-border">
                  <p className="text-sm text-white">{message.text}</p>
                </div>
                <span className="text-xs text-white/60 mt-2 block text-right">
                  {formatTime(message.timestamp)}
                </span>
              </div>
              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex-shrink-0 flex items-center justify-center pulse-glow">
                <User className="w-4 h-4 text-white" />
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <div className="p-6 border-t border-white/10">
        <form onSubmit={handleSubmit} className="flex space-x-3">
          <Input
            type="text"
            placeholder="Type a message..."
            value={messageInput}
            onChange={(e) => setMessageInput(e.target.value)}
            className="flex-1 glass border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent text-white placeholder-white/60 px-4 py-3"
          />
          <Button
            type="submit"
            disabled={!messageInput.trim()}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-6 py-3 rounded-xl transition-all btn-modern glow-border disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
          </Button>
        </form>
      </div>
    </div>
  );
}
