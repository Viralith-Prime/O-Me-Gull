import { Users, X } from "lucide-react";
import { Button } from "@/components/ui/button";

interface LoadingModalProps {
  isOpen: boolean;
  onCancel: () => void;
}

export function LoadingModal({ isOpen, onCancel }: LoadingModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 modal-backdrop flex items-center justify-center p-4 z-50">
      <div className="glass rounded-2xl p-8 max-w-sm w-full border border-white/20">
        <div className="text-center">
          <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mx-auto mb-6 flex items-center justify-center pulse-glow float-animation">
            <Users className="w-10 h-10 text-white" />
          </div>
          <div className="mb-6">
            <div className="spinner mx-auto mb-4"></div>
          </div>
          <h3 className="text-2xl font-bold text-white mb-3 gradient-text">
            Finding someone to chat with...
          </h3>
          <p className="text-white/80 mb-8 text-sm leading-relaxed">
            This may take a moment
          </p>
          <Button
            onClick={onCancel}
            variant="outline"
            className="w-full glass border-white/30 text-white hover:bg-white/10 px-6 py-3 rounded-xl font-semibold transition-all btn-modern flex items-center justify-center space-x-2"
          >
            <X className="w-4 h-4" />
            <span>Cancel</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
