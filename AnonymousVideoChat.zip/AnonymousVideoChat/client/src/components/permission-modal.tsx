import { Video, Camera, Mic } from "lucide-react";
import { Button } from "@/components/ui/button";

interface PermissionModalProps {
  isOpen: boolean;
  onGranted: () => void;
  onDenied: () => void;
}

export function PermissionModal({ isOpen, onGranted, onDenied }: PermissionModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 modal-backdrop flex items-center justify-center p-4 z-50">
      <div className="glass rounded-2xl p-8 max-w-md w-full border border-white/20">
        <div className="text-center">
          <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full mx-auto mb-6 flex items-center justify-center pulse-glow float-animation">
            <Video className="w-10 h-10 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-white mb-3 gradient-text">
            Camera & Microphone Access
          </h3>
          <p className="text-white/80 mb-8 text-sm leading-relaxed">
            This app needs access to your camera and microphone to enable video chat. 
            Your privacy is protected - no data is stored.
          </p>
          
          <div className="flex flex-col space-y-4 mb-8">
            <div className="flex items-center space-x-4 p-4 glass-dark rounded-xl float-animation">
              <Camera className="w-6 h-6 text-blue-400" />
              <div className="text-left">
                <p className="text-sm font-semibold text-white">Camera Access</p>
                <p className="text-xs text-white/70">Required for video calling</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4 p-4 glass-dark rounded-xl float-animation" style={{animationDelay: '0.2s'}}>
              <Mic className="w-6 h-6 text-green-400" />
              <div className="text-left">
                <p className="text-sm font-semibold text-white">Microphone Access</p>
                <p className="text-xs text-white/70">Required for audio communication</p>
              </div>
            </div>
          </div>
          
          <div className="flex space-x-4">
            <Button
              onClick={onDenied}
              variant="outline"
              className="flex-1 glass border-white/30 text-white hover:bg-white/10 px-6 py-3 rounded-xl font-semibold transition-all btn-modern"
            >
              Not Now
            </Button>
            <Button
              onClick={onGranted}
              className="flex-1 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white px-6 py-3 rounded-xl font-semibold transition-all btn-modern glow-border"
            >
              Grant Access
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
