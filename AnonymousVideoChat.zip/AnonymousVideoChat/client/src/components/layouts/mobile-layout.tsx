import { useState, useRef, useEffect } from 'react';
import { MessageCircle, Mic, MicOff, Video, VideoOff, SkipForward, X, User, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import type { DeviceInfo, LayoutConfig } from '@/hooks/use-device-manager';

interface Message {
  id: string;
  text: string;
  sender: 'self' | 'partner';
  timestamp: Date;
}

interface MobileLayoutProps {
  deviceInfo: DeviceInfo;
  layoutConfig: LayoutConfig;
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  isVideoEnabled: boolean;
  isAudioEnabled: boolean;
  onToggleVideo: () => void;
  onToggleAudio: () => void;
  onFindPartner: () => void;
  onEndChat: () => void;
  hasPartner: boolean;
  messages: Message[];
  onSendMessage: (message: string) => void;
}

export function MobileLayout({
  deviceInfo,
  layoutConfig,
  localStream,
  remoteStream,
  isVideoEnabled,
  isAudioEnabled,
  onToggleVideo,
  onToggleAudio,
  onFindPartner,
  onEndChat,
  hasPartner,
  messages,
  onSendMessage
}: MobileLayoutProps) {
  const [showChat, setShowChat] = useState(false);
  const [showLocalVideo, setShowLocalVideo] = useState(true);
  const [showSwarmPanel, setShowSwarmPanel] = useState(false);
  const [messageInput, setMessageInput] = useState('');
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream, showLocalVideo]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Re-initialize video when it becomes visible again
  useEffect(() => {
    if (showLocalVideo && localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [showLocalVideo, localStream]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (messageInput.trim()) {
      onSendMessage(messageInput.trim());
      setMessageInput('');
    }
  };

  const formatTime = (timestamp: Date) => {
    return timestamp.toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true
    });
  };

  return (
    <div className="fixed inset-0 gradient-bg flex flex-col">
      {/* Status Bar */}
      <div className="glass backdrop-blur-md px-4 py-2 border-b border-white/10 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="w-6 h-6 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center glow-border">
            <Video className="text-white w-3 h-3" />
          </div>
          <span className="text-white text-sm font-medium">VideoChat</span>
        </div>

        <div className="flex items-center space-x-3">
          <Button
            onClick={() => setShowSwarmPanel(!showSwarmPanel)}
            className="glass rounded-full w-8 h-8 p-0 border-white/20 text-white"
          >
            <Eye className="w-4 h-4" />
          </Button>

          <Button
            onClick={() => setShowChat(!showChat)}
            className="glass rounded-full w-8 h-8 p-0 border-white/20 text-white relative"
          >
            <MessageCircle className="w-4 h-4" />
            {messages.filter(m => m.sender === 'partner').length > 0 && (
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full flex items-center justify-center">
                <span className="text-xs text-white">{messages.filter(m => m.sender === 'partner').length}</span>
              </div>
            )}
          </Button>

          <div className={`w-2 h-2 rounded-full ${
            hasPartner ? 'bg-green-400 pulse-glow' : 'bg-red-400'
          }`} />
        </div>
      </div>

      {/* Video Feed */}
      <div className="flex-1 relative overflow-hidden bg-black">
        {/* Partner Video - Full Screen */}
        <div className="absolute inset-0 w-full h-full">
          {remoteStream ? (
            <video
              ref={remoteVideoRef}
              className="w-full h-full object-cover"
              autoPlay
              playsInline
              style={{ 
                width: '100%',
                height: '100%',
                objectFit: 'cover'
              }}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center glass-dark">
              <div className="text-center text-white float-animation">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full mx-auto mb-3 flex items-center justify-center pulse-glow">
                  <User className="w-8 h-8" />
                </div>
                <p className="text-sm opacity-90">Waiting for partner...</p>
                <div className="mt-3">
                  <div className="spinner mx-auto"></div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Local Video - Picture in Picture - Fixed Positioning */}
        {localStream && showLocalVideo && (
          <div 
            className="absolute glass-dark rounded-lg overflow-hidden z-20 glow-border shadow-2xl"
            style={{
              bottom: '120px',
              right: '16px',
              width: '140px',
              height: '105px',
              minWidth: '140px',
              minHeight: '105px',
              maxWidth: '140px',
              maxHeight: '105px',
              transform: 'translate3d(0, 0, 0)',
              backfaceVisibility: 'hidden',
              position: 'fixed',
              zIndex: 30
            }}
          >
            <video
              ref={localVideoRef}
              className="w-full h-full object-cover"
              autoPlay
              playsInline
              muted
              key={`local-video-${showLocalVideo}`}
              style={{ 
                transform: 'scaleX(-1)',
                width: '100%',
                height: '100%',
                objectFit: 'cover',
                display: 'block'
              }}
            />
            {!isVideoEnabled && (
              <div className="absolute inset-0 w-full h-full flex items-center justify-center glass-dark bg-black/60">
                <div className="text-center text-white">
                  <div className="w-8 h-8 bg-gradient-to-r from-red-500 to-pink-500 rounded-full mx-auto mb-1 flex items-center justify-center">
                    <VideoOff className="w-4 h-4" />
                  </div>
                  <p className="text-xs opacity-90">Camera Off</p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Always show local video preview when stream exists */}
        {localStream && !showLocalVideo && (
          <div 
            className="absolute glass-dark rounded-lg overflow-hidden z-20 glow-border shadow-2xl opacity-30"
            style={{
              bottom: '120px',
              right: '16px',
              width: '60px',
              height: '45px',
              position: 'fixed',
              zIndex: 25
            }}
          >
            <div className="w-full h-full flex items-center justify-center glass-dark">
              <Eye className="w-4 h-4 text-white opacity-60" />
            </div>
          </div>
        )}

        {/* Floating Controls */}
        <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex items-center space-x-3 z-20 px-4"
             style={{ 
               position: 'fixed',
               bottom: '24px',
               left: '50%',
               transform: 'translateX(-50%)',
               zIndex: 40
             }}>
          <button
            onClick={onToggleAudio}
            className={`w-12 h-12 glass rounded-full flex items-center justify-center transition-all btn-modern ${
              isAudioEnabled ? 'text-white' : 'text-red-400'
            }`}
          >
            {isAudioEnabled ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
          </button>

          <button
            onClick={onToggleVideo}
            className={`w-12 h-12 glass rounded-full flex items-center justify-center transition-all btn-modern ${
              isVideoEnabled ? 'text-white' : 'text-red-400'
            }`}
          >
            {isVideoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
          </button>

          <button
            onClick={() => setShowLocalVideo(!showLocalVideo)}
            className="w-12 h-12 glass rounded-full flex items-center justify-center transition-all btn-modern text-white"
            title={showLocalVideo ? "Hide camera view" : "Show camera view"}
          >
            {showLocalVideo ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
          </button>

          <Button
            onClick={hasPartner ? onEndChat : onFindPartner}
            disabled={!localStream}
            className={`${
              hasPartner 
                ? 'bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600' 
                : 'bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600'
            } text-white px-4 py-3 rounded-full font-semibold transition-all btn-modern glow-border disabled:opacity-50 flex items-center space-x-2 text-sm`}
          >
            {hasPartner ? (
              <>
                <X className="w-4 h-4" />
                <span>End</span>
              </>
            ) : (
              <>
                <SkipForward className="w-4 h-4" />
                <span>Next</span>
              </>
            )}
          </Button>
        </div>
      </div>

      {/* SwarmIntelligencePanel Overlay */}
      {showSwarmPanel && (
        <div className="fixed top-16 left-4 right-4 z-50">
          <div className="glass-transparent rounded-lg p-4 backdrop-blur-lg bg-black/20 border border-white/10">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <div className="w-5 h-5 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                  <Eye className="w-3 h-3 text-white" />
                </div>
                <h3 className="text-white font-semibold text-sm">AI Swarm Intelligence</h3>
              </div>
              <button
                onClick={() => setShowSwarmPanel(false)}
                className="w-6 h-6 glass rounded-full flex items-center justify-center text-white"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
            <div className="text-xs text-white/80 space-y-2">
              <div>Status: Active</div>
              <div>Performance: Optimized</div>
              <div>Security: Protected</div>
            </div>
          </div>
        </div>
      )}

      {/* Transparent Chat Overlay */}
      {showChat && (
        <div className="fixed inset-0 flex items-end justify-center z-50 pointer-events-none p-4">
          <div className="glass-transparent rounded-t-3xl w-full max-w-md h-3/4 border-t border-white/10 flex flex-col pointer-events-auto backdrop-blur-lg bg-black/20">
            {/* Chat Header */}
            <div className="flex justify-between items-center p-4 border-b border-white/10">
              <h3 className="text-white font-semibold text-lg">Chat</h3>
              <button
                onClick={() => setShowChat(false)}
                className="w-8 h-8 glass rounded-full flex items-center justify-center text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.length === 0 && (
                <div className="text-center">
                  <span className="glass text-white/80 px-4 py-2 rounded-full text-sm">
                    Start a conversation...
                  </span>
                </div>
              )}

              {messages.map((message) => {
                if (message.sender === 'self' && (message.text === 'Connected to chat' || message.text === 'Partner disconnected')) {
                  return (
                    <div key={message.id} className="text-center message-enter">
                      <span className={`glass px-4 py-2 rounded-full text-sm ${
                        message.text === 'Connected to chat' ? 'text-green-400' : 'text-red-400'
                      }`}>
                        {message.text}
                      </span>
                    </div>
                  );
                }

                if (message.sender === 'partner') {
                  return (
                    <div key={message.id} className="flex space-x-3 message-enter">
                      <div className="w-8 h-8 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex-shrink-0 flex items-center justify-center">
                        <User className="w-4 h-4 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="glass-dark rounded-2xl px-4 py-3 max-w-xs">
                          <p className="text-sm text-white">{message.text}</p>
                        </div>
                        <span className="text-xs text-white/60 mt-1 block">
                          {formatTime(message.timestamp)}
                        </span>
                      </div>
                    </div>
                  );
                }

                return (
                  <div key={message.id} className="flex space-x-3 justify-end message-enter">
                    <div className="flex-1">
                      <div className="bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl px-4 py-3 max-w-xs ml-auto">
                        <p className="text-sm text-white">{message.text}</p>
                      </div>
                      <span className="text-xs text-white/60 mt-1 block text-right">
                        {formatTime(message.timestamp)}
                      </span>
                    </div>
                    <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex-shrink-0 flex items-center justify-center">
                      <User className="w-4 h-4 text-white" />
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Chat Input */}
            <div className="p-4 border-t border-white/10">
              <form onSubmit={handleSendMessage} className="flex space-x-3">
                <Input
                  type="text"
                  placeholder="Type a message..."
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  className="flex-1 glass border-white/20 rounded-xl text-white placeholder-white/60 px-4 py-3"
                />
                <Button
                  type="submit"
                  disabled={!messageInput.trim()}
                  className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-6 py-3 rounded-xl transition-all btn-modern disabled:opacity-50"
                >
                  Send
                </Button>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}