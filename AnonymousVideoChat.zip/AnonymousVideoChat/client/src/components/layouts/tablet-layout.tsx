import { useState, useRef, useEffect } from 'react';
import { MessageCircle, Mic, MicOff, Video, VideoOff, SkipForward, X, User, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import type { DeviceInfo, LayoutConfig } from '@/hooks/use-device-manager';

interface Message {
  id: string;
  text: string;
  sender: 'self' | 'partner';
  timestamp: Date;
}

interface TabletLayoutProps {
  deviceInfo: DeviceInfo;
  layoutConfig: LayoutConfig;
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  isVideoEnabled: boolean;
  isAudioEnabled: boolean;
  onToggleVideo: () => void;
  onToggleAudio: () => void;
  onFindPartner: () => void;
  onEndChat: () => void;
  hasPartner: boolean;
  messages: Message[];
  onSendMessage: (message: string) => void;
}

export function TabletLayout({
  deviceInfo,
  layoutConfig,
  localStream,
  remoteStream,
  isVideoEnabled,
  isAudioEnabled,
  onToggleVideo,
  onToggleAudio,
  onFindPartner,
  onEndChat,
  hasPartner,
  messages,
  onSendMessage
}: TabletLayoutProps) {
  const [messageInput, setMessageInput] = useState('');
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const isPortrait = deviceInfo.orientation === 'portrait';

  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (messageInput.trim()) {
      onSendMessage(messageInput.trim());
      setMessageInput('');
    }
  };

  const formatTime = (timestamp: Date) => {
    return timestamp.toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true
    });
  };

  // Portrait mode - similar to mobile
  if (isPortrait) {
    return (
      <div className="min-h-screen gradient-bg flex flex-col">
        {/* Header */}
        <header className="glass backdrop-blur-md px-6 py-4 border-b border-white/10">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3 float-animation">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center glow-border">
                <Video className="text-white w-4 h-4" />
              </div>
              <h1 className="text-xl font-semibold text-white">VideoChat</h1>
            </div>
            
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full status-dot ${
                hasPartner ? 'bg-green-400 status-connected pulse-glow' : 'bg-red-400 status-disconnected'
              }`} />
              <span className="text-sm text-white/80 capitalize">{hasPartner ? 'connected' : 'disconnected'}</span>
            </div>
          </div>
        </header>

        {/* Single Column Layout */}
        <main className="flex-1 p-6 flex flex-col space-y-6">
          {/* Video Section */}
          <div className="glass rounded-2xl p-6 flex-1 min-h-[400px]">
            <div className="grid grid-cols-1 gap-6 h-full">
              {/* Remote Video */}
              <div className="relative glass-dark rounded-2xl overflow-hidden aspect-video video-container glow-border">
                {remoteStream ? (
                  <video
                    ref={remoteVideoRef}
                    className="w-full h-full object-cover"
                    autoPlay
                    playsInline
                  />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center text-white float-animation">
                      <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full mx-auto mb-4 flex items-center justify-center pulse-glow">
                        <User className="w-10 h-10" />
                      </div>
                      <p className="text-lg opacity-90">Waiting for partner...</p>
                      <div className="mt-4">
                        <div className="spinner mx-auto"></div>
                      </div>
                    </div>
                  </div>
                )}
                
                <div className="absolute bottom-4 left-4">
                  <span className="glass text-white px-3 py-1 rounded-full text-sm font-medium">
                    Partner
                  </span>
                </div>
              </div>

              {/* Local Video */}
              <div className="relative glass-dark rounded-2xl overflow-hidden aspect-video video-container glow-border">
                {localStream ? (
                  <video
                    ref={localVideoRef}
                    className="w-full h-full object-cover scale-x-[-1]"
                    autoPlay
                    playsInline
                    muted
                  />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center text-white float-animation">
                      <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mx-auto mb-4 flex items-center justify-center pulse-glow">
                        <User className="w-10 h-10" />
                      </div>
                      <p className="text-lg opacity-90">Camera not available</p>
                    </div>
                  </div>
                )}
                
                <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center">
                  <span className="glass text-white px-3 py-1 rounded-full text-sm font-medium">
                    You
                  </span>
                  
                  <div className="flex space-x-3">
                    <button
                      onClick={onToggleVideo}
                      className={`w-10 h-10 glass rounded-full flex items-center justify-center transition-all btn-modern ${
                        isVideoEnabled ? 'text-white' : 'text-red-400'
                      }`}
                    >
                      {isVideoEnabled ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={onToggleAudio}
                      className={`w-10 h-10 glass rounded-full flex items-center justify-center transition-all btn-modern ${
                        isAudioEnabled ? 'text-white' : 'text-red-400'
                      }`}
                    >
                      {isAudioEnabled ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Controls */}
            <div className="pt-6 border-t border-white/10 mt-6">
              <div className="flex justify-center">
                <Button
                  onClick={hasPartner ? onEndChat : onFindPartner}
                  disabled={!localStream}
                  className={`${
                    hasPartner 
                      ? 'bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600' 
                      : 'bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600'
                  } text-white px-8 py-4 rounded-xl font-semibold transition-all btn-modern glow-border disabled:opacity-50 flex items-center space-x-3 text-lg`}
                >
                  {hasPartner ? (
                    <>
                      <X className="w-5 h-5" />
                      <span>End Chat</span>
                    </>
                  ) : (
                    <>
                      <SkipForward className="w-5 h-5" />
                      <span>Next</span>
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>

          {/* Chat Section */}
          <div className="glass rounded-2xl p-6 h-80">
            <h2 className="font-semibold text-white flex items-center space-x-3 mb-4">
              <MessageCircle className="w-5 h-5 text-purple-400" />
              <span>Chat</span>
            </h2>

            <div className="flex flex-col h-full">
              <div className="flex-1 overflow-y-auto space-y-4 mb-4">
                {messages.length === 0 && (
                  <div className="text-center">
                    <span className="glass text-white/80 px-4 py-2 rounded-full text-sm">
                      Start a conversation...
                    </span>
                  </div>
                )}

                {messages.map((message) => {
                  if (message.sender === 'self' && (message.text === 'Connected to chat' || message.text === 'Partner disconnected')) {
                    return (
                      <div key={message.id} className="text-center message-enter">
                        <span className={`glass px-4 py-2 rounded-full text-sm ${
                          message.text === 'Connected to chat' ? 'text-green-400' : 'text-red-400'
                        }`}>
                          {message.text}
                        </span>
                      </div>
                    );
                  }

                  if (message.sender === 'partner') {
                    return (
                      <div key={message.id} className="flex space-x-3 message-enter">
                        <div className="w-8 h-8 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex-shrink-0 flex items-center justify-center">
                          <User className="w-4 h-4 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="glass-dark rounded-2xl px-4 py-3 max-w-xs">
                            <p className="text-sm text-white">{message.text}</p>
                          </div>
                          <span className="text-xs text-white/60 mt-1 block">
                            {formatTime(message.timestamp)}
                          </span>
                        </div>
                      </div>
                    );
                  }

                  return (
                    <div key={message.id} className="flex space-x-3 justify-end message-enter">
                      <div className="flex-1">
                        <div className="bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl px-4 py-3 max-w-xs ml-auto">
                          <p className="text-sm text-white">{message.text}</p>
                        </div>
                        <span className="text-xs text-white/60 mt-1 block text-right">
                          {formatTime(message.timestamp)}
                        </span>
                      </div>
                      <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex-shrink-0 flex items-center justify-center">
                        <User className="w-4 h-4 text-white" />
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>

              <form onSubmit={handleSendMessage} className="flex space-x-3">
                <Input
                  type="text"
                  placeholder="Type a message..."
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  className="flex-1 glass border-white/20 rounded-xl text-white placeholder-white/60 px-4 py-3"
                />
                <Button
                  type="submit"
                  disabled={!messageInput.trim()}
                  className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-6 py-3 rounded-xl transition-all btn-modern disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </form>
            </div>
          </div>
        </main>
      </div>
    );
  }

  // Landscape mode - custom tablet layout
  return (
    <div className="min-h-screen gradient-bg flex flex-col">
      {/* Header */}
      <header className="glass backdrop-blur-md px-6 py-4 border-b border-white/10">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-3 float-animation">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center glow-border">
              <Video className="text-white w-4 h-4" />
            </div>
            <h1 className="text-xl font-semibold text-white">VideoChat</h1>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full status-dot ${
              hasPartner ? 'bg-green-400 status-connected pulse-glow' : 'bg-red-400 status-disconnected'
            }`} />
            <span className="text-sm text-white/80 capitalize">{hasPartner ? 'connected' : 'disconnected'}</span>
          </div>
        </div>
      </header>

      {/* Main Content - Landscape Layout */}
      <main className="flex-1 p-6 flex space-x-6">
        {/* Video Section */}
        <div className="flex-1 flex flex-col space-y-4">
          {/* Main Remote Video (65% of screen) */}
          <div className="flex-1 relative glass-dark rounded-2xl overflow-hidden video-container glow-border">
            {remoteStream ? (
              <video
                ref={remoteVideoRef}
                className="w-full h-full object-cover"
                autoPlay
                playsInline
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-white float-animation">
                  <div className="w-24 h-24 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full mx-auto mb-6 flex items-center justify-center pulse-glow">
                    <User className="w-12 h-12" />
                  </div>
                  <p className="text-xl opacity-90">Waiting for partner...</p>
                  <div className="mt-4">
                    <div className="spinner mx-auto"></div>
                  </div>
                </div>
              </div>
            )}
            
            <div className="absolute bottom-4 left-4">
              <span className="glass text-white px-3 py-1 rounded-full text-sm font-medium">
                Partner
              </span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex justify-center space-x-4">
            <button
              onClick={onToggleAudio}
              className={`w-12 h-12 glass rounded-full flex items-center justify-center transition-all btn-modern ${
                isAudioEnabled ? 'text-white' : 'text-red-400'
              }`}
            >
              {isAudioEnabled ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
            </button>

            <button
              onClick={onToggleVideo}
              className={`w-12 h-12 glass rounded-full flex items-center justify-center transition-all btn-modern ${
                isVideoEnabled ? 'text-white' : 'text-red-400'
              }`}
            >
              {isVideoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
            </button>

            <Button
              onClick={hasPartner ? onEndChat : onFindPartner}
              disabled={!localStream}
              className={`${
                hasPartner 
                  ? 'bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600' 
                  : 'bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600'
              } text-white px-6 py-3 rounded-xl font-semibold transition-all btn-modern glow-border disabled:opacity-50 flex items-center space-x-2`}
            >
              {hasPartner ? (
                <>
                  <X className="w-4 h-4" />
                  <span>End</span>
                </>
              ) : (
                <>
                  <SkipForward className="w-4 h-4" />
                  <span>Next</span>
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Sidebar */}
        <div className="w-80 flex flex-col space-y-4">
          {/* Local Video (15% - small) */}
          <div className="h-48 relative glass-dark rounded-2xl overflow-hidden video-container glow-border">
            {localStream ? (
              <video
                ref={localVideoRef}
                className="w-full h-full object-cover scale-x-[-1]"
                autoPlay
                playsInline
                muted
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-white">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mx-auto mb-2 flex items-center justify-center">
                    <User className="w-6 h-6" />
                  </div>
                  <p className="text-sm opacity-90">Camera off</p>
                </div>
              </div>
            )}
            
            <div className="absolute bottom-2 left-2">
              <span className="glass text-white px-2 py-1 rounded-full text-xs font-medium">
                You
              </span>
            </div>
          </div>

          {/* Chat Section */}
          <div className="flex-1 glass rounded-2xl p-4 flex flex-col">
            <h2 className="font-semibold text-white flex items-center space-x-2 mb-4">
              <MessageCircle className="w-4 h-4 text-purple-400" />
              <span>Chat</span>
            </h2>

            <div className="flex-1 overflow-y-auto space-y-3 mb-4">
              {messages.length === 0 && (
                <div className="text-center">
                  <span className="glass text-white/80 px-3 py-1 rounded-full text-xs">
                    Start a conversation...
                  </span>
                </div>
              )}

              {messages.map((message) => {
                if (message.sender === 'self' && (message.text === 'Connected to chat' || message.text === 'Partner disconnected')) {
                  return (
                    <div key={message.id} className="text-center message-enter">
                      <span className={`glass px-3 py-1 rounded-full text-xs ${
                        message.text === 'Connected to chat' ? 'text-green-400' : 'text-red-400'
                      }`}>
                        {message.text}
                      </span>
                    </div>
                  );
                }

                if (message.sender === 'partner') {
                  return (
                    <div key={message.id} className="flex space-x-2 message-enter">
                      <div className="w-6 h-6 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex-shrink-0 flex items-center justify-center">
                        <User className="w-3 h-3 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="glass-dark rounded-xl px-3 py-2">
                          <p className="text-xs text-white">{message.text}</p>
                        </div>
                        <span className="text-xs text-white/60 mt-1 block">
                          {formatTime(message.timestamp)}
                        </span>
                      </div>
                    </div>
                  );
                }

                return (
                  <div key={message.id} className="flex space-x-2 justify-end message-enter">
                    <div className="flex-1">
                      <div className="bg-gradient-to-r from-purple-500 to-blue-500 rounded-xl px-3 py-2 ml-auto max-w-[200px]">
                        <p className="text-xs text-white">{message.text}</p>
                      </div>
                      <span className="text-xs text-white/60 mt-1 block text-right">
                        {formatTime(message.timestamp)}
                      </span>
                    </div>
                    <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex-shrink-0 flex items-center justify-center">
                      <User className="w-3 h-3 text-white" />
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            <form onSubmit={handleSendMessage} className="flex space-x-2">
              <Input
                type="text"
                placeholder="Type a message..."
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                className="flex-1 glass border-white/20 rounded-lg text-white placeholder-white/60 px-3 py-2 text-sm"
              />
              <Button
                type="submit"
                disabled={!messageInput.trim()}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-3 py-2 rounded-lg transition-all btn-modern disabled:opacity-50"
              >
                <Send className="w-3 h-3" />
              </Button>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
}